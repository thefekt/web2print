<?php
/**
 * Storechild hooks
 *
 * @package storechild
 */

add_action( 'init', 'storechild_hooks' );

/**
 * Add and remove Storechild/Storefront functions.
 *
 * @return void
 */
function storechild_hooks() {

}

// define the woocommerce_before_single_product callback 
function action_woocommerce_before_single_product( $wc_print_notices, $int ) { 
    echo('<div id=\"visionr-div"><h3> BABA </h3> </div> ')
}; 
         
// add the action 
add_action( 'woocommerce_before_single_product', 'action_woocommerce_before_single_product', 10, 2 );